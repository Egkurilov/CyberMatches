from cybermatches.bot.app import run


if __name__ == "__main__":
    run()
